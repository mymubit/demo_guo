# Drama Skills 进化日志

> 记录技能库进化。双轨道唯一定义见 drama-intake/SKILL.md（阶段 E）；提交外部内容见 INTAKE_PROTOCOL.md。

## 双轨道（引用 drama-intake 定义）

| 轨道 | 名称 | 触发 | 写入位置 |
|------|------|------|----------|
| A | 规则升级 | 方法论/频率/LR；评分连续 2 次 <70；模式 3+ 升格 | oundation/rules/*.yaml |
| B | 素材沉淀 | 灵感案例 / 市场数据 / 待验证模式 | inspirations/inspirations.md 或 knowledge/market/market-insights.md |

旧四轨对照：一→A；二/三/四→B（升格仍走 A）。

## v5.0 基线（2026-07-02）

- **角色**：8 个 = 4 主链生产（topic-director / story-bible / episode-designer / script-writer）+ 3 质检环独立技能（script-scorer / compliance-guard / revision-master）+ 1 可选工具（delivery-tool）
- **编排**：双通道 `orchestration/original-track.yaml`（原创）/ `story-adapt-track.yaml`（故事改编），在 story_bible 汇合
- **质检环**：默认先评分再合规（B′；可配置并行）；低于 B 级（75）或 P1 → 修复 → 强制复评
- **规则**：四 Scope 不变（global_core / genre_profile / stage_playbook / compliance_block）

## 变更记录

### 2026-07-21 · 阶段 E：进化瘦身（4→2 轨 + inspirations 单文件）

- **双轨道**：A 规则升级 / B 素材沉淀（定义收敛于 `drama-intake/SKILL.md` v5.1）
- **inspirations**：五文件正文合并为 `inspirations/inspirations.md`；旧文件保留为指针（可回滚）
- **质检**：默认串行评分→合规已由 B′ 落地（见总纲）；本阶段不重复改编排
- **市场路径不变**：`market-insights.md` 仍为行业动态写入点（归轨道 B）

### 2026-07-20 · 零兼容硬切（Skills 契约层）

- **交付项统一**：工作台字段、`persist_path` 与 `runtime_projection` 全面改用 `deliverables`（`creation_preferences.deliverables`）；删除 `delivery_items` 双读路径
- **题材硬切**：删除 `genres/fallback.yaml`；`validate_skills` 断言 `genres/` 仅允许 `matrix.yaml`；未匹配题材规则 → 运行时硬错误（见 Runtime 任务）
- **identity 清理**：`theme-matrix.yaml` tag prefer 与 `output-schemas.md` 示例移除 `dual-lead`，对齐 `returning-elite`

### 2026-07-16 · v5.2 全库审计修复（数值收口 + 题材矩阵 v2 + 契约闭合）

- **数值收口**：新增 `foundation/constraints/narrative-metrics.yaml`（开场分层窗口 3s/10s/30s、S级铺垫 5 集、冲突密度 S1.5/A1.0/B0.5），裁决并消除 rules/knowledge 双源冲突（LR-005 vs plotting、10秒 vs 30秒、40-60% vs 55-75%、1.2 vs 1.5）
- **合规提取补全**：恐怖内容三级处置、正义收束 35% 结尾窗口与触发词/正义词/洗白词清单、备案材料清单进入 `compliance-core.yaml`；`platform-profiles.yaml` 补种子检查项；删除 tier4 长文中的死索引区块（new_2026_p0_items 等，正文不存在）
- **题材矩阵 v2.0**：受众频道（男频/女频/普适）升为必选维度；identity 轴 dual-lead → returning-elite（强者归来）；主角结构独立字段；标签 69→72（增战神/神医/高手下山/都市玄幻/真假千金/读心/先婚后爱/反派女配，删 5 个受众标签升维迁移）并分 hot/standard/longtail；新增 tag_constraints 互斥/世界观依赖；合成幂等（canonical 标签顺序）；推断词表去歧义并补男频词
- **注入断链修复**：`genre-profile.yaml` → `genres/fallback.yaml`（进入 genre_profile 真实加载路径）；`memory_checkpoint.producer` = script-writer；`artifacts.yaml` 新增 field_writers 唯一写入者声明
- **门禁跟随预设**：质检环与交付门禁改读当前 `scoring_preset` 的 pass_threshold ∧ delivery_eligible；`scoring-presets.yaml` 增平台推荐映射
- **状态机补洞**：`all_batches_quality_passed` guard（末批质检对齐）、`project_brief_rejected/changed` 选题返工回流（仅原创通道）、`delivery_skipped` 自动事件声明；工作流场景 3→7 + guard 负向回归
- **参数来源闭合**：workbench 新增 `command_scope_params`；校验器强制角色参数被 projection ∪ command_scope 完整覆盖
- **双源治理**：删除 `foundation/methodology/*`（与 philosophy.yaml 重复）与 `artifact-chunk-map.yaml`（空壳指针）；`theme-templates.md` 降为指针页；`market-insights.md` 收敛为摄入区（基准表 SSOT = industry-benchmarks）；灵感库四文件挂载到 hook/dialogue/reversal/structure 模块
- **校验器强化**：SKILL 参数漂移检测（清零 15 处）、模块七段结构检查、题材幂等与约束校验、golden cases 15→24（preset 门禁 + 题材合成/约束拒绝）
- 注：v5.0 记录中提到的 `artifact-chunk-map.yaml` 兼容别名已在本版删除；`docs/DRAMA-SKILLS-V5-PLAN.md` 从未入库，相关链接已移除

### 2026-07-14 · 五阶段可执行契约与回归体系

- **产物 Schema**：8 类业务产物与 memory checkpoint 全部具备 JSON Schema、合法样例和非法输入回归
- **配置解析**：实现后台白名单覆盖、条件表达式、项目参数投影、版本审计和追加式回滚参考实现
- **流程状态机**：实现双通道、蓝图审批、并行质检、修复收敛、幂等、乐观锁和 latest_script 解析
- **工作台交付**：新增表单 JSON 导出器和 API 契约；实际页面由 ScriptForge 网站消费
- **质量回归**：新增15个确定性 golden cases、标准库单元测试和 GitHub Actions 门禁

### 2026-07-14 · 最新态净化与生产基建补全

- **零兼容运行时**：删除3个兼容模块、旧题材规则包、旧产物别名和双份 params 列表
- **统一当前剧本**：评分、合规、修复和交付只消费 `latest_script` 虚拟产物
- **创作基建补全**：新增世界规则、首稿对白、制片可拍性和连续性终审
- **制作发行补全**：新增预算分级、平台上架清单和制片复杂度后台配置
- **角色数保持8**：新增能力均有清晰归属和既有产物，无需为恢复历史数量制造微角色

### 2026-07-14 · 角色技能组合与工作台配置契约

- **角色组合落地**：11 个 foundation 模块正式挂载主链角色，正文官补齐场景写作与连续性快照
- **职责校正**：九列分镜从修复官迁至交付工具；修复官支持基于最新修复稿继续迭代，并读取蓝图/分集防止越界
- **参数结构化**：8 个角色的运行参数增加类型、枚举、必填条件与 UI 元数据
- **工作台契约**：新增项目设置分组、阶段导航、模块面板和后台设置来源；主题、集数、平台与质量偏好可直接生成表单
- **后台边界**：新增路径级 overlay 白名单，角色、规则、编排、题材枚举与产物契约保持 Git 只读
- **编排门禁**：蓝图人工确认、分集前置产物、结构化质检条件、最多三轮修复和异常趋势停机进入机器契约

### 2026-07-14 · 底层原子规则重新抽取与基础能力补全

- **分层固定**：knowledge 仅保留知识原料；constraints 维护数值与结构；rules 维护原子规则；modules 只组合执行流程
- **数值收敛**：新增商业公式、结构缩放、十维评分预设、连续性检查点和平台配置入口；清除题材模板、评分和格式中的重复阈值
- **规则补全**：新增概念形成、全剧结构/分集卡/连续性、原创性规则；扩展合规、人物和场景写作规则
- **模块补全**：新增概念、改编原创性、人物、全剧结构、情绪、反转伏笔、分集卡、付费卡点、场景写作和连续性快照等基础模块
- **校验增强**：新增模块目录、原子规则唯一性/SSOT方向、十维预设权重和流式产物定义校验

### 2026-07-02 · v5.1 底层技能深度治理（模块充实 + 规则合并 + 知识分目录 + 配置分级）

- **模块去空心化**：16 个 modules 从 3 行存根充实为「目标/执行步骤/量化标准/自检清单」结构的可执行操作指南（30-60 行/个），并标注挂载角色与数值 SSOT
- **规则文件合并（17→12，运行时透明）**：dialogue-voice+ai-tone-forbidden→`dialogue-rules.yaml`；writing-requirements+writing-prohibitions→`writing-rules.yaml`；conflict-escalation+foreshadowing-rules+payment-checkpoint→`plotting-rules.yaml`；character-logic→`character-rules.yaml`（扩充密度/弧光条目）；genre-profile fallback 强化为可执行摘要+默认参数；rule_key/section 全部保留
- **规则 body 治理**：可执行内容内联进 body，knowledge 指针降级为「长文参考」注释（规则条目是 prompt 实际载体，指针背后的内容运行时读不到）
- **knowledge 按消费场景分 5 目录**：craft/（创作方法论）、market/（时效市场数据，后台配置候选）、quality/（质检标准）、production/（制作宣发）、system/（流程控制）；`knowledge-sections.md`、`output-schemas.md` 留在根目录（后端固定路径解析）；全库引用路径同步更新
- **配置分级标注**：constraints 文件头部声明 `config_tier`——agent-runtime=seed_default（后台 drama-models 可覆盖）；quality-scoring 的阈值/熔断与 script-format 的字数/占比=seed_default（建议后台 system_config 覆盖）；格式 pattern、chunk-map=git_ssot
- **校验器升级**：`validate_skills.py` 新增 knowledge 孤儿检测、模块孤儿检测、全库相对路径引用有效性、角色↔Section 映射存在性 4 项检查

### 2026-07-02 · v5.0 主链收缩 + 双通道 + 质检环 + 进化机制补全

- **角色 9→8**：`drama.character-relations` + `drama.series-architect` 合并为 `drama.story-bible`（剧本蓝图官，双模式：原创/改编），modules 与 sections 全量随迁，能力零丢失（映射见 `ROLE-DESIGN-ANALYSIS.md`）
- **新产物** `story-bible.v1` = character-bible.v1 ∪ series-outline.v1 ∪ 梗概层；旧两键保留为兼容别名（`artifact-chunk-map.yaml`）
- **修复主链断链**：评分官/合规官输入改为 `required_artifacts_any_of`（polished_script > episode_scripts > external_script），修复稿强制复评
- **编排重写**：`fast-track.yaml` / `expert-track.yaml` / `ip-adapt.yaml` → `original-track.yaml` + `story-adapt-track.yaml`（expert 与 fast 的差异由 optional_agents 表达；ip-adapt 由改编通道真正实现）
- **阈值收敛**：B 级统一为 75（`quality-scoring.yaml` SSOT）；`s-class-standards.md`、`scoring-presets.md` 对齐
- **进化机制补全**：四轨道统一定义收敛至 `drama-intake/SKILL.md`（修复三处编号互相矛盾）；评分官新增进化提案规则（stage-playbook `t3.drama-script-scorer.scoring.evolution-proposal`）；`quality-report.v1` 增加 `evolution_proposal` 字段
- **stage-playbook 补缺**：新增 compliance-guard（合规裁判边界）与 delivery-tool（交付前置门禁）条目
- **知识库清理**：15+ 处旧角色名引用（topic-planner / market-analyst / quality-reporter / script-reviewer / hook-designer / ip-adapter / game-adapter / rhythm-designer / storyboard-director 等）全部改指 v5 角色；孤儿长文挂接到对应角色 SKILL references（s-class-standards / scoring-presets → 评分官；douyin-formulas / industry-benchmarks / market-insights → 选题官；originality-rules / 山音编剧长文 → 蓝图官；导演方法论 → 修复官/交付工具；story-to-game → 交付工具）
- **新增校验**：`build/validate_skills.py` 全库一致性校验（registry ↔ roles ↔ orchestration ↔ rules ↔ references）

### 2026-06-25 · 题材矩阵 v1.4

- 风味标签 48→69（12 类：赛博朋克/末世/竖屏互动/年代重生/黑帮/互换身体等）
- featured_combos 20→32；新增 `topic_planner_inference` 关键词推断
- 新增 `build/validate_theme_matrix.py`

### 2026-06-25 · 题材矩阵全量覆盖 v1.3

- 四轴扩至 9×9×9×9（6561 骨架组合）
- 风味标签 48 项 / 10 类，最多选 5
- 创新组合 featured_combos 扩至 20 条
- 约定：高分新组合 → `inspirations/inspirations.md`「待验证模式」归档驱动进化

### 2026-06-25 · 四轴扩展 7+7+7+7 + 风味标签层

- 每轴 5→7 项（喜剧/正义、青春/守护、罪案/阶级、校园/科幻等）
- 新增 `flavor_tags`（18 项，最多选 3）覆盖武侠/修仙/医疗/无限流等长尾
- `synthesize_matrix_params.py` 支持 flavor_tags 叠加

### 2026-06-25 · 四轴直驱规则参数（废弃 archetype 硬映射）

- 四轴路径：`theme_code=matrix` + `rule_params` 由 `param_synthesis` 合成
- 8 预设降为「快捷卡片」，不再 weighted_score 映射
- 新增 `foundation/rules/genres/matrix.yaml`、`build/synthesize_matrix_params.py`

### 2026-06-25 · 四轴矩阵与规则模板对齐

- 新增 `foundation/theme-matrix.yaml`（创作层 SSOT + matrix_affinity 映射）
- `theme-templates.md` 重定位为「8 规则模板 + hybrid」，与四轴解耦说明
- `project-brief.v1` 增加 `genre_matrix` 字段

### 2026-06-25 · 阶段规则文档重命名

- `knowledge/tier3-node-rules.md` → `tier3-stage-rules.md`（去除 Node 旧命名）
- `stage-playbook.yaml` 中 `scope_type: node` → `scope_type: agent`

### 2026-06-25 · SKILL frontmatter 统一

- 移除全部 `tier` / `is_fast_track` / `merges` / `is_composite` 字段
- composite 角色改用 `modules:` 列表（与 `role.yaml` 对齐）
- `drama-intake` 路由表对齐 `INTAKE_PROTOCOL.md`（规则写入 `foundation/rules/`）
- 清理 `tier4-compliance.md`、`inspirations/` 中旧角色名引用

### 2026-06-25 · 文档与仓库瘦身

- 移除应用层代码，本目录为唯一 SSOT
- 统一全部文档至 v3.1 术语（无后端/dept/旧角色体系引用）
- `SKILL.md` 仅保留 Cursor 入口；规则全部在 `foundation/rules/`

### 2026-06-25 · 规则补全

- 新增 `learned-rules.yaml`、`conflict-escalation.yaml`、`genres/hybrid.yaml`
- 扩展 plot-architect / narrative-engineer / script-writer 的 section 覆盖

---

*后续变更请在本文件顶部「变更记录」追加条目。*
