# 模块：钩子体系

> 挂载角色：`drama.episode-designer`（集首/集末钩子设计）

## 目标

为每集设计达标的集末钩子与首集开场钩子，保证付费卡点前钩子强度。

## 输入

- 本集分集卡、下一集首场与付费节点

## 引用规则

- `t1.global.hook_effectiveness.levels`
- `t1.global.rhythm_rules.hook-density`
- `t1.global.learned_rules.lr003`
- `foundation/constraints/commercial-formulas.yaml`
- `foundation/constraints/narrative-metrics.yaml#opening_hook`（分层窗口数值 SSOT）

钩子等级、密度、开场窗口与付费要求由上述规则和约束定义，本模块不重复维护。
灵感库（可选参考）：`inspirations/inspirations.md`（钩子创意）。

## 黄金开场（首集，窗口数值见 narrative-metrics）

```
第一层 视觉冲击：强情绪画面（被扇耳光/婚礼逃跑/雨中下跪），不允许铺垫背景
第二层 信息建立：谁、和谁、什么冲突（主钩子成立）
第三层 悬念确立：抛出第一个「为什么」
```

## 输出

- `narrative_plan.episode_narrative_designs[].hook`（集末钩子 + `hook_grade` 等级）
- 首集开场三层钩子设计

## 集末钩子四种写法

1. **未解问题**：抛出新疑问（那封信里写了什么？）
2. **新威胁**：更强对手/更大危机登场
3. **关系悬崖**：关键关系走到临界点（离婚协议递出的瞬间切黑）
4. **信息炸弹**：观众先于角色得知重大信息

要求：钩子必须与下一集首场直接衔接，禁止「钩子归钩子、下集另起炉灶」。

## 执行步骤

1. 逐集判定钩子类型（四种写法选一）并写明等级
2. 校验付费卡点前一集钩子达到 LR-003 要求
3. 首集按三层窗口逐层设计并自查衔接

## 失败条件

- 集末无钩子或钩子与下集首场脱节。
- 首集开场先铺垫背景再进冲突。

## 自检清单

- [ ] 每集集末 B 级以上钩子，且写明钩子等级（hook_grade）
- [ ] 付费卡点前一集集末为全剧最强钩子之一
- [ ] 首集黄金 30 秒三段齐全
- [ ] 90% 的集末钩子能让人立即想看下一集（自问：我会划走吗？）
