# 模块：视觉锚点

> 挂载角色：`drama.delivery-tool`（宣发视觉物料）
> 风格参考：`knowledge/production/shanyin-director-styles.md`（六维度导演风格库）

## 目标

为每个核心角色和关键场景产出「15 秒内可识别」的视觉标识与 AI 图像/视频 Prompt。

## 输入

- `story_bible.characters[].visual_anchor`
- `latest_script` 最强冲突/反转场景（切片 Prompt 来源）

## 引用规则

- `t1.global.originality.ai-rights`（AI 形象与声纹权利约束）
- `knowledge/production/shanyin-director-styles.md`（六维风格库长文）

## 输出

- `production_package.visual_assets[]`（角色锚点/风格关键词/海报与切片 Prompt）

## 执行步骤

1. **角色视觉锚点**：从 story_bible 的 `visual_anchor` 字段提取每个核心角色的标志性视觉元素（服装/道具/发型/体态），补全为完整外观描述
2. **风格定调**：按题材从六维度风格库选定情绪基调维度（A 维度对短剧最直接有用），输出全剧视觉关键词 3-5 个
3. **海报/封面 Prompt**：主视觉 1 版 + 备选 2 版，每版含主体/构图/光线/色调/风格标签
4. **高光切片视频 Prompt**：为 3 个最强冲突/反转场景写视频生成提示词
5. **技术规格**：竖屏 9:16；单镜 3-8 秒；封面文字预留顶部 1/5 空间

## Prompt 结构模板

```
[主体描述含视觉锚点] + [情绪/动作] + [场景与光线] + [景别与构图] + [风格标签] + 9:16 vertical
```

## 失败条件

- 角色 Prompt 之间不可区分。
- Prompt 与既有 IP 视觉高度相似（肖像权风险）。

## 自检清单

- [ ] 每个核心角色有独立视觉锚点且互相区分
- [ ] Prompt 不含与现有 IP 相似的视觉描述（AI 漫剧肖像权风险，见 `knowledge/quality/originality-rules.md`）
- [ ] 全部物料标注 9:16 与用途（封面/投流/切片）
