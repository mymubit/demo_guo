# -*- coding: utf-8 -*-
"""流程状态机（移植自 runtime/workflow_engine.py）。"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


class WorkflowError(ValueError):
    """非法流程操作。"""


class ConcurrencyError(WorkflowError):
    """状态版本冲突。"""


PHASE_ORDER = (
    "strategy",
    "blueprint",
    "episode_design",
    "writing",
    "delivery",
)

PHASE_ARTIFACTS: dict[str, tuple[str, ...]] = {
    "strategy": ("project_brief",),
    "blueprint": ("story_bible",),
    "episode_design": ("narrative_plan",),
    "writing": (
        "episode_scripts",
        "polished_script",
        "quality_report",
        "compliance_report",
    ),
    "delivery": ("production_package",),
}


def detect_trend(scores: list[float]) -> str | None:
    if len(scores) < 2:
        return None
    previous, current = scores[-2:]
    if abs(current - previous) < 1:
        return "stagnant"
    if len(scores) >= 3:
        first, second, third = scores[-3:]
        if (second - first) * (third - second) < 0:
            return "oscillating"
    if current < previous:
        return "diverging"
    return None


def resolve_latest_script(
    artifacts: dict[str, Any],
    episode_range: str | None = None,
) -> dict[str, Any]:
    for key in ("polished_script", "episode_scripts", "external_script"):
        value = artifacts.get(key)
        if value is None:
            continue
        if episode_range and isinstance(value, dict) and episode_range in value:
            return {"resolved_script_key": key, "value": value[episode_range]}
        return {"resolved_script_key": key, "value": value}
    raise WorkflowError("不存在可解析的 latest_script")


def _clear_from_phase(state: dict[str, Any], phase: str) -> None:
    if phase not in PHASE_ORDER:
        raise WorkflowError(f"未知重跑阶段: {phase}")
    start = PHASE_ORDER.index(phase)
    artifacts = state.setdefault("artifacts", {})
    confirmations = state.setdefault("stage_confirmations", {})
    for item in PHASE_ORDER[start:]:
        for key in PHASE_ARTIFACTS.get(item, ()):
            artifacts.pop(key, None)
        confirmations.pop(item, None)
    if start <= PHASE_ORDER.index("blueprint"):
        state.setdefault("approvals", {})["story_bible_approved"] = False
    if start <= PHASE_ORDER.index("writing"):
        state["batch_cursor"] = 1
        state["last_quality_passed_batch"] = 0
        state["revision_round"] = 0
        state["quality_results"] = {}
        state["score_history"] = []


def _write_confirmation(state: dict[str, Any], payload: dict[str, Any]) -> None:
    phase = state.get("current_phase")
    if not phase or phase == "completed":
        return
    # blueprint_approval 历史阶段：确认记在 blueprint
    key = "blueprint" if phase == "blueprint_approval" else str(phase)
    conf = state.setdefault("stage_confirmations", {})
    conf[key] = {
        "confirmed_at": str(
            payload.get("confirmed_at")
            or datetime.now(timezone.utc).isoformat()
        ),
        "confirmed_by": str(payload.get("confirmed_by") or ""),
    }


@dataclass
class WorkflowEngine:
    transitions: dict[str, Any]
    max_revision_rounds: int = 3

    def create(self, project_id: str, entry_type: str) -> dict[str, Any]:
        initial = (self.transitions.get("initial_phase") or {}).get(entry_type)
        if not initial:
            raise WorkflowError(f"未知入口: {entry_type}")
        return {
            "schema_version": "workflow-state.v1",
            "project_id": project_id,
            "version": 0,
            "entry_type": entry_type,
            "status": "active",
            "current_phase": initial,
            "approvals": {},
            "stage_confirmations": {},
            "batch_cursor": 1,
            "last_quality_passed_batch": 0,
            "revision_round": 0,
            "score_history": [],
            "quality_results": {},
            "artifacts": {},
            "processed_commands": [],
            "blocked_reason": None,
            "pending_user_options": [],
        }

    def apply(
        self,
        state: dict[str, Any],
        event: str,
        command_id: str,
        expected_version: int,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if command_id in state["processed_commands"]:
            return copy.deepcopy(state)
        if state["version"] != expected_version:
            raise ConcurrencyError(
                f"期望版本 {expected_version}，实际 {state['version']}"
            )
        payload = payload or {}
        transition = self._select_transition(state, event, payload)
        if transition is None:
            raise WorkflowError(
                f"阶段 {state['current_phase']} 不接受事件 {event}"
            )
        result = copy.deepcopy(state)
        if "stage_confirmations" not in result:
            result["stage_confirmations"] = {}
        self._run_action(result, transition.get("action"), payload)
        to = transition["to"]
        if to == "$payload.phase":
            to = str(payload.get("phase") or "").strip()
            if not to:
                raise WorkflowError("stage_rework 需要 payload.phase")
        result["current_phase"] = to
        result["status"] = transition.get("status", "active")
        result["processed_commands"].append(command_id)
        result["version"] += 1
        return result

    def decide(
        self,
        state: dict[str, Any],
        decision: str,
        command_id: str,
        expected_version: int,
    ) -> dict[str, Any]:
        if state["status"] != "waiting_user":
            raise WorkflowError("当前不等待用户决策")
        definition = (self.transitions.get("user_decisions") or {}).get(decision)
        if not definition:
            raise WorkflowError(f"未知用户决策: {decision}")
        synthetic = {
            "to": definition["to"],
            "status": definition.get("status", "active"),
            "action": definition.get("action"),
        }
        runtime = copy.deepcopy(self.transitions)
        runtime.setdefault("transitions", []).insert(
            0,
            {
                "from": state["current_phase"],
                "event": f"user:{decision}",
                **synthetic,
            },
        )
        return WorkflowEngine(runtime, self.max_revision_rounds).apply(
            state,
            f"user:{decision}",
            command_id,
            expected_version,
        )

    def _select_transition(
        self,
        state: dict[str, Any],
        event: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        for transition in self.transitions.get("transitions", []):
            if transition.get("event") != event:
                continue
            if transition.get("from") not in ("*", state["current_phase"]):
                continue
            if self._guard_passes(state, transition.get("guard"), payload or {}):
                return transition
        return None

    def _guard_passes(
        self,
        state: dict[str, Any],
        guard: str | None,
        payload: dict[str, Any] | None = None,
    ) -> bool:
        payload = payload or {}
        if guard is None:
            return True
        if guard == "quality_join_complete":
            return {"score", "compliance"} <= set(state["quality_results"])
        if guard == "can_auto_revise":
            return (
                state["revision_round"] < self.max_revision_rounds
                and detect_trend(state["score_history"]) is None
            )
        if guard == "must_stop":
            return not self._guard_passes(state, "can_auto_revise")
        if guard == "is_original_track":
            return state.get("entry_type") == "original_track"
        if guard == "has_story_bible":
            artifacts = state.get("artifacts") or {}
            return bool(artifacts.get("story_bible"))
        if guard == "all_batches_quality_passed":
            total = payload.get("total_batches")
            if not isinstance(total, int) or total < 1:
                return False
            return state.get("last_quality_passed_batch", 0) >= total
        if guard == "phase_matches_payload":
            phase = str(payload.get("phase") or "").strip()
            status = state.get("status")
            return (
                phase == state.get("current_phase")
                and status in ("waiting_stage_confirm", "waiting_approval")
            )
        if guard == "can_rework_phase":
            phase = str(payload.get("phase") or "").strip()
            if phase not in PHASE_ARTIFACTS:
                return False
            confirmations = state.get("stage_confirmations") or {}
            if phase in confirmations:
                return False
            return phase == state.get("current_phase") and state.get("status") in (
                "waiting_stage_confirm",
                "waiting_approval",
                "active",
            )
        raise WorkflowError(f"未知 guard: {guard}")

    def _run_action(
        self,
        state: dict[str, Any],
        action: str | None,
        payload: dict[str, Any],
    ) -> None:
        if action is None:
            return
        if action == "approve_story_bible":
            state.setdefault("approvals", {})["story_bible_approved"] = True
            state.setdefault("stage_confirmations", {})["blueprint"] = {
                "confirmed_at": str(
                    payload.get("confirmed_at")
                    or datetime.now(timezone.utc).isoformat()
                ),
                "confirmed_by": str(payload.get("confirmed_by") or ""),
            }
        elif action == "confirm_stage":
            _write_confirmation(state, payload)
        elif action == "confirm_blueprint_stage":
            _write_confirmation(state, payload)
            state.setdefault("approvals", {})["story_bible_approved"] = True
        elif action == "rework_stage":
            phase = str(payload.get("phase") or "").strip()
            _clear_from_phase(state, phase)
        elif action == "rework_from_strategy":
            _clear_from_phase(state, "strategy")
            state["artifacts"].pop("project_brief", None)
        elif action == "rework_blueprint_reject":
            _clear_from_phase(state, "blueprint")
        elif action == "reset_quality_join":
            state["quality_results"] = {}
        elif action == "record_quality_score":
            score = float(payload["overall_score"])
            state["score_history"].append(score)
            state["quality_results"]["score"] = payload
        elif action == "record_compliance":
            state["quality_results"]["compliance"] = payload
        elif action == "increment_revision_round":
            state["revision_round"] += 1
        elif action == "advance_batch":
            state["last_quality_passed_batch"] = state["batch_cursor"]
            state["batch_cursor"] += 1
            state["revision_round"] = 0
            state["quality_results"] = {}
        elif action == "require_user_decision":
            state["pending_user_options"] = [
                "accept_current",
                "manual_revision",
                "abandon_batch",
            ]
            state["blocked_reason"] = detect_trend(state["score_history"]) or (
                "max_revision_rounds"
            )
        elif action == "invalidate_downstream":
            state.setdefault("approvals", {})["story_bible_approved"] = False
            for key in (
                "narrative_plan",
                "episode_scripts",
                "polished_script",
                "quality_report",
                "compliance_report",
                "production_package",
            ):
                state["artifacts"].pop(key, None)
            conf = state.setdefault("stage_confirmations", {})
            for key in ("episode_design", "writing", "delivery", "blueprint"):
                conf.pop(key, None)
            state["revision_round"] = 0
            state["quality_results"] = {}
        elif action == "invalidate_from_strategy":
            state.setdefault("approvals", {})["story_bible_approved"] = False
            for key in (
                "project_brief",
                "story_bible",
                "narrative_plan",
                "episode_scripts",
                "polished_script",
                "quality_report",
                "compliance_report",
                "production_package",
            ):
                state["artifacts"].pop(key, None)
            state["stage_confirmations"] = {}
            state["batch_cursor"] = 1
            state["last_quality_passed_batch"] = 0
            state["revision_round"] = 0
            state["quality_results"] = {}
        else:
            raise WorkflowError(f"未知 action: {action}")
